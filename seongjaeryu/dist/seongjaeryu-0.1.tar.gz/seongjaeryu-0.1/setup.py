from setuptools import setup

setup(name='seongjaeryu',
      version='0.1',
      description="Seongjae Ryu's personal Python setting",
      packages=['distributions'],
      keywords='seongjae ryu',
      author='Seongjae Ryu',
      author_email='seongjaeryu@gmail.com',
      url='https://seongjaeryu.com',
      zip_safe=False)