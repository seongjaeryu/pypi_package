from jupyterthemes import jtplot

def main():
    jtplot.style()
    print(f"'jtplot.style()' Applied for plot on darken theme.")

if __name__ == '__main__':
    main()